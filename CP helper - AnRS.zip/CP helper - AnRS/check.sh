g++ main.cpp -o main && ./main < input.txt > output.txt && bash diff.sh expected_output.txt output.txt
