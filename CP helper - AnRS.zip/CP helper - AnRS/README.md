Copy these files into a same folder and run the commands to do the following things:

Open main.cpp input.txt ouput.txt expected_output.txt in a text editor


# Run these commands in Ubuntu terminal:
./fresh.sh -> Readymade template in main.cpp
./out.sh -> output.txt shows the output based on input.txt
./check.sh -> to check if your output is the same as the expected output
./vscode.sh -> open the necessary files in vscode
