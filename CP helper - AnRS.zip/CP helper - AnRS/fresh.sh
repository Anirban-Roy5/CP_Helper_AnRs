cat template.txt > main.cpp
cat empty.txt > input.txt
cat empty.txt > output.txt
cat empty.txt > expected_output.txt
