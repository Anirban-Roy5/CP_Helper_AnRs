code main.cpp input.txt output.txt expected_output.txt
