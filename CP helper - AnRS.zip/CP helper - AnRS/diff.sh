#!/bin/bash

file1_name=$1
file2_name=$2

diff -qw $file1_name $file2_name

if [ $? -eq 0 ]; then
  echo -e "\033[1;32mTestcase Passed...!!!\033[0m"
else
  echo -e "\033[1;31mTestcase Failed...!!!\033[0m"
fi
