g++ main.cpp -o main && ./main < input.txt > output.txt
